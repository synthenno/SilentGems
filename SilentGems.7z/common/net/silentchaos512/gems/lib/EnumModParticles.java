package net.silentchaos512.gems.lib;

public enum EnumModParticles {

  CHAOS,
  CHAOS_PROJECTILE_BODY,
  CHAOS_PACKET_HEAD,
  CHAOS_PACKET_TAIL,
  CHAOS_NODE,
  PHANTOM_LIGHT,
  DRAWING_COMPASS,
  FREEZING,
  SHOCKING;
}
