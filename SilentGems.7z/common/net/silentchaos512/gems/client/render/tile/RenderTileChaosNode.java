package net.silentchaos512.gems.client.render.tile;

import net.silentchaos512.gems.tile.TileChaosNode;
import net.silentchaos512.lib.client.render.tileentity.TileEntitySpecialRendererSL;

public class RenderTileChaosNode extends TileEntitySpecialRendererSL<TileChaosNode> {

  @Override
  public void clRender(TileChaosNode te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {

  }
}
